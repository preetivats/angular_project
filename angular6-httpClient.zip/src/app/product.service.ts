import { Injectable } from '@angular/core';
import { Product } from './product';
import { PRODUCTS } from './mock-product';
import { Observable, of } from 'rxjs';
import { MessageService } from './message.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}


@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productUrl = 'https://api.myjson.com/bins/15gwki';


  constructor(private _messageService: MessageService, private _http: HttpClient) { }

  getProductService(): Observable<{ PRODUCTS: Product[] }> {
    // this._messageService.add('Fetch heroes');
    //return of(PRODUCTS);

    return this._http.get<{ PRODUCTS: Product[] }>(this.productUrl).pipe(
      catchError(this.handleError<any>('updateHeroes'))
    );

  }

  // updateProduct(product: any): Observable<any> {
  //   return this._http.put(this.productUrl, product, httpOptions).pipe(
  //     catchError(this.handleError<{ PRODUCTS: Product[] }>('getHeroes'))
  //   );

  // }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };


  }

  /** Log a HeroService message with the MessageService */
  private log(message: string) {
    this._messageService.add(`HeroService: ${message}`);
  }

}
