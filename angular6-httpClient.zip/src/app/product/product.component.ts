import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService} from '../product.service';
import{ MessageComponent} from '../message/message.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {

products: Product[];
selectedProduct: Product;

obj =  {name :"abc"};

  constructor(private _productService: ProductService) {  }

  evilTitle = 'Template <script>alert("evil never sleeps")</script>Syntax';
  actionName="Copy";

  isSpecial: Boolean = true;

  ngOnInit() {
    this.getProducts();

    let obj1 = {...this.obj};

    obj1.name = "sdasdasdasd";
  }

  onSelect(prod: Product):void{
    this.selectedProduct = prod;

  }

  getProducts(): void{
    this._productService.getProductService().subscribe((prod)=>{
      this.products = prod.PRODUCTS;
    
    })
  }

}
