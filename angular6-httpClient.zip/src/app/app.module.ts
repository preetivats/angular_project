import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product-add/product-add.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { MessageComponent } from './message/message.component';
import { SizerComponent } from './sizer/sizer.component';


const appRoutes: Routes = [
  { path: 'product', component: ProductComponent},
  { path: 'product-detail/:id', component: ProductDetailComponent},
  { path: 'product-add', component: ProductAddComponent},
  { path: 'product-edit', component: ProductEditComponent},
  { path: '', redirectTo: '/product', pathMatch: 'full'}
]


@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    ProductAddComponent,
    ProductDetailComponent,
    ProductEditComponent,
    MessageComponent,
    SizerComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    FormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})



export class AppModule { }
