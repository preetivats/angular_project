import { Product} from './product';

export const PRODUCTS: Product[] = [
    {id: 1, name: 'Table'},
    {id: 2, name: 'chair'},
    {id: 3, name: 'Telephone'},
    {id: 4, name: 'Bottle'},
    {id: 5, name: 'Lunch Box'}
]

