import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-sizer',
  templateUrl: './sizer.component.html',
  styleUrls: ['./sizer.component.scss']
})
export class SizerComponent {
@Input() size: number;
@Output() sizeChange = new EventEmitter<number>();
counter : number = 16;
  constructor() { }

  dec() {
    this.resize(-1);
  }
  inc() {
    this.resize(+1);
  }

  resize(n : number) {
    this.size = Math.min(40, Math.max(8, +this.size + n));
    this.sizeChange.emit(this.size)
  }

}
