import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../product';
import { ProductService} from '../product.service';
import { Location} from '@angular/common';
import { isArray } from 'util';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailComponent {
@Input() prod: Product;

  constructor(private _productService: ProductService, private _location: Location) { }

  // goBack():void{
  //   this._location.back();
  // }


  // save():void{
  //   this._productService.updateProduct(this.prod).subscribe(()=>this.goBack());
  // }

}
