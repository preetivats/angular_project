import { Component } from '@angular/core';
//import {MessageComponent} from './message/message.component'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular6-httpClient';
  fontSizePx : number = 16;
   newFontSize : number=16;
  changeFontSize(data){
    this.newFontSize = data;
  }
}
